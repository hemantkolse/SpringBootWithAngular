import { Component,OnInit } from '@angular/core';
import { MyServiceService } from './my-service.service';
import { Http } from '@angular/http';
import 'rxjs/add/operator/map';
import { HttpClient } from '@angular/common/http';
import { FormGroup, FormControl } from '@angular/forms';
import { Body } from '@angular/http/src/body';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit{
  title = 'Angular4-App';
  todayDate;
  httpdata;
  httpdata2;
  formdata;

  // create new book record in H2 DB
  bookdata:Object;
  loading:boolean;
  book={
    "isbn":"33333333333111",
    "title":"Effective Java",
    "description":"hihihi",
    "authors":[{
        "firstName":"Jaya",
        "lastName":"Blosh"
        
      }],
    "publisher":"Addison Wesley"
      
    }

//Update record in H2 DB by isbn id

    bookdataUpdate:Object;
    loadingUpdate:boolean;
    bookUpdate={
      "isbn":"978-1617292545",
      "title":"Effective Java Updated",
      "description":"hihihi Updated",
      "authors":[{
          "firstName":"Jaya Updated",
          "lastName":"Blosh Updated"
          
        }],
      "publisher":"Addison Wesley Updated"
        
      }

      ookdataUpdatePatch:Object;
    loadingUpdatePatch:boolean;
    
  constructor(private http:HttpClient)
  {}
  ngOnInit() {
    
    // fetch all book record from h2 database
/*
    this.http.get('http://localhost:8080/api/books').
    subscribe(data => {
      var responseData = JSON.stringify(data);
      this.displaydataAll(data);
   console.log(' all available book fetch from H2 DB are : '+responseData);
    });

    // fetch book by isbn id from h2 database

    this.http.get('http://localhost:8080/api/books/6666666666').subscribe(data2 => {
      var responseData2 = JSON.stringify(data2);
      this.displaydataByisbn(data2);
   console.log('book record fetch from H2 DB by isbn id is : '+responseData2);
    });

  console.log("custom data3 :"+JSON.stringify(this.book));

    // insert book into h2 database

    this.http.post('http://localhost:8080/api/books', this.book).subscribe((res: Response) => {
      console.log("book record added in H2 DB :"+res);
      this.bookdata = res;
      this.loading = false;
    }, err=>console.log(err));

    //Update book into h2 database by isbn id
*/
    this.http.put('http://localhost:8080/api/books/978-1617292545', this.bookUpdate).subscribe((res: Response) => {
      console.log("book record updated in H2 DB by isbn id :"+res);
      this.bookdataUpdate = res;
      this.loadingUpdate = false;
    }, err=>console.log(err));

/*
    // delete book by id from h2

    this.http.delete('http://localhost:8080/api/books/33333333333111').subscribe((res: Response) => {
      console.log("book record deleted by isbn id from H2 DB :"+res);
      this.bookdataUpdate = res;
      this.loadingUpdate = false;
    }, err=>console.log(err));

*/
    // delete all book from h2

    this.http.delete('http://localhost:8081/api/books').subscribe((res: Response) => {
      console.log("all book record deleted from h2 DB"+res);
     
    }, err=>console.log(err));

  /*  

    // update book by specific field from h2 (using PATCH api)

    this.http.patch('http://localhost:8080/api/books/333333333331',"Content updated by patch api").subscribe((res: Response) => {
      console.log("book record deleted by isbn id from H2 DB :"+res);
      this.bookdataUpdate = res;
      this.loadingUpdate = false;
    }, err=>console.log(err));

*/
  }
  
  displaydataAll(data) 
  {
    this.httpdata = data;
    
  }

  displaydataByisbn(data) 
  {
    this.httpdata2 = data;
    
  }
  onClickSubmit(data) {
    alert("Entered Email id : " + data.emailid);
 }

}
