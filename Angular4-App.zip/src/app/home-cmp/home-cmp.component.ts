import { Component, OnInit } from '@angular/core';
import { MyServiceService } from '../my-service.service';

@Component({
  selector: 'app-home-cmp',
  templateUrl: './home-cmp.component.html',
  styleUrls: ['./home-cmp.component.css']
})
export class HomeCmpComponent implements OnInit {
todayDate;
  constructor(private service:MyServiceService) { }

  ngOnInit() {
    this.todayDate=this.service.getDate();
  }

}
