package com.github.sbouclier.javarestbooks.exception;

public class UserNotFoundException extends RuntimeException{

	 public UserNotFoundException(Integer id) {
	        super("could not find User with ID: '" + id + "'");
	    }
	}

