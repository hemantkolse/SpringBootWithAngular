package com.github.sbouclier.javarestbooks.exception;

public class UserIdAlreadyExistsException extends RuntimeException{
	
	public UserIdAlreadyExistsException(String id) {
	        super("book already exists for ID: '" + id + "'");
	    }

}
