package com.github.sbouclier.javarestbooks.controller;

import java.util.List;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.github.sbouclier.javarestbooks.domain.User;

@RestController
@RequestMapping("/user/api/")
public class UserController {

	
	@GetMapping("/getAllUser")
	public List<User> getAllUsers()
	{
		
	}
	
	@GetMapping("/getUser/{id}")
	public User getUserById(@PathVariable("id")int id)
	{
		
	}
	
	@PostMapping("/createUser/{user}")
	public User createUser(@RequestBody("user")User user)
	{
		
	}
	
	@PostMapping("/updateUser/{user}")
	public void updateUser(@RequestBody("user")User user)
	{
		
	}
	
	@DeleteMapping("/deleteUser/{id}")
	public void deleteUser(@PathVariable("id")int id)
	{
		
	}
	
	
}


 