package com.github.sbouclier.javarestbooks.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import com.github.sbouclier.javarestbooks.domain.Book;
import com.github.sbouclier.javarestbooks.domain.User;

public interface UserRepository extends PagingAndSortingRepository<User, Integer> {
	
	 
	 Optional<User> findUserById(Integer id);
}



